\echo Use "CREATE EXTENSION plaudit" to load this file.\quit
